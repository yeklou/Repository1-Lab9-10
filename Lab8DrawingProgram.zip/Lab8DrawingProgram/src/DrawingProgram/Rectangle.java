/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DrawingProgram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author National Pawn
 */
public class Rectangle extends Shape {
   
    private int width;
    private int length;
    private Color color;
    
    public Rectangle(int x, int y, Color color, int width, int length) {
        super(x, y, color);
     super.setX(x);
     super.setY(y);
     super.setColor(color);
     this.width = width;
     this.length = length;
    }

    @Override
    public void draw(Graphics2D g) {
      g.setColor(this.getColor());
      g.drawRect(this.getX(), this.getY(), width, length);
    }

    @Override
    public double getArea() {
        double Area = width * length;
        return Area;
    } 
}
