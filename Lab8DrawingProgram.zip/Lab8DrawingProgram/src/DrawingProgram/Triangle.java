/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DrawingProgram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author National Pawn
 */
public class Triangle extends Shape{
    int base;
    int height;
public Triangle(int x, int y, int base, int height,  Color color){
   super(x, y, color);
  super.setX(x);
  super.setY(y);
  super.setColor(color);
  this.height = height;
  this.base = base;
}
 
    @Override
    public void draw(Graphics2D g) {
        g.setColor(this.getColor());
        int[] X = {super.getX() + base,   super.getX(), super.getX()};
        int[] Y = {super.getY(), super.getY()+height, super.getY()};
        g.drawPolygon(X, Y, 3);
    }

    @Override
    public double getArea() {
        double area = 0.5* base* height;
       return area; 
    }
    
}
