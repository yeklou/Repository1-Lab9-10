/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab9ExceptionHandling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author lcao2
 */
public class Lab9ExceptionHandling {

    public static void main(String[] args) {
       // getMessage();
      // try{
      //  System.out.println(getInteger());
      // }catch(IOException e){
     //    System.out.println( "There is an exception");
      // }
       
      int[] arr = { 4, 5, 7, 2, 5};
      int divisor = 1;
      for(int i=0; i < arr.length; i++){
      System.out.println(arr[i]/divisor);
      
      }
    }
    
        
    public static void getMessage(){
        
        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter a message");
        try{
            String line = keyboard.readLine();
            System.out.println("You entered: " + line);
        }catch(IOException e){
            System.out.println("There is an IOException");
          
        }
     
     }
    
    
    public static int getInteger()throws IOException{
    int input = 0;
    BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Enter an integer");
    input = Integer.valueOf(keyboard.readLine());
    return input;
    }
}

