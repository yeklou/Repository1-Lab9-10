/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataStructures;

import ADTs.StackADT;
import Exceptions.EmptyCollectionException;

/**
 *
 * @author ITCS2214
 */
public class LinkedStack<T> implements StackADT<T> {

    int count;
    SingleLinkedNode<T> top;
    
    public LinkedStack(){
        //TODO
        top = null;
        count = 0;

    }
    
    public LinkedStack(T data){
        //TODO
        top = new SingleLinkedNode(data);
        count = 1;

    }
    
    @Override
    public void push(T element) {
        //TODO
        SingleLinkedNode<T> temp = new SingleLinkedNode<T>(element);
        temp.setNext(top);
        top = temp;
        count++;

    }

    @Override
    public T pop() throws EmptyCollectionException {
        //TODO
        if(this.isEmpty()) throw new EmptyCollectionException();
        SingleLinkedNode<T> node  = top;
       top =top.getNext();
       count--;
       node.setNext(null);
      return node.getElement();
    }

    @Override
    public T peek() throws EmptyCollectionException {
        
        //TODO
        if(this.isEmpty()) throw new EmptyCollectionException();
        SingleLinkedNode<T> temp = top;
        return temp.getElement();
            

    }

    @Override
    public boolean isEmpty() {
        //TODO
        boolean result = false;
        if(this.size() == 0)
            result = true;
      return result;
    }

    @Override
    public int size() {
        //TODO
            return count;

    }

    @Override
    public String toString() {
        if (top != null) {
            return "LinkedListStack{" + "count=" + count + ", top=" + top.getElement() + '}';
        } else {
            return "LinkedListStack{" + "count=" + count + '}';
        }
    }

    public static void main(String argv[]){
        StackADT<String> cities = new LinkedStack<String>();
        try{
            cities.push("Tokyo");
            cities.push("Atlanta");
            cities.pop();
            cities.pop();
            cities.push("Miami");
            cities.pop();
            cities.push("Charlotte");
            					System.out.println("Charlotte".equalsIgnoreCase(cities.peek()));
            System.out.println(1 == cities.size());
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
    
}
