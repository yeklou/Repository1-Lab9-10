/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataStructures;
import Exceptions.*;
import ADTs.*;
/**
 *
 * @author clatulip
 * Adapted by ITCS 2214
 */
public class DoubleLinkedList<T extends Comparable> implements ListADT<T> {

    protected DoubleLinkedNode<T> first;
    protected DoubleLinkedNode<T> last;
    protected int numNodes;

    public DoubleLinkedList() {
        //TODO

    }

    @Override
    public void addFirst(T element) {
        //TODO

    }

    @Override
    public void addLast(T element) {
        //TODO

    }

    @Override
    public void addAfter(T existing, T element) throws ElementNotFoundException, EmptyCollectionException {
        //TODO

    
    }

    @Override
    public T remove(T element) throws EmptyCollectionException, ElementNotFoundException {
        return null;
        //TODO
        
    }

    @Override
    public T removeFirst() throws EmptyCollectionException {
        return null;
        //TODO
    }

    @Override
    public T removeLast() throws EmptyCollectionException {
        return null;
        //TODO
    }



    @Override
    public T first() throws EmptyCollectionException {
        return null;
        //TODO
    }

    @Override
    public T last() throws EmptyCollectionException {
        return null;
        //TODO
    }

    @Override
    public boolean isEmpty() {
        return false;
        //TODO
    }

    @Override
    public int size() {
        return 0;
        //TODO
    }

    @Override
    public boolean contains(T element) throws EmptyCollectionException {
        
        return false;
        //TODO
    }

    @Override
    public T get(int index) throws EmptyCollectionException, InvalidArgumentException {
        if (numNodes == 0) {
            throw new EmptyCollectionException();
        }
        
        // validate the input
        if (index < 0 || index >= numNodes) {
            throw new InvalidArgumentException();
        }
        
	   //TODO
        return null;

    }

    @Override
    public void set(int index, T element) throws EmptyCollectionException, InvalidArgumentException {
        if (numNodes == 0) {
            throw new EmptyCollectionException();
        }
        
        // validate the input
        if (element == null || index < 0 || index >= numNodes) {
            throw new InvalidArgumentException();
        }
        
        //TODO
    }
    
    /**
     * Returns a string representation of the collection
     * @return a string representation of the collection
     */
    @Override
    public String toString(){
        DoubleLinkedNode<T> temp = first;
        
        String result = "";
        while (temp != null) {
            result += temp.getElement()  + " -> ";
            temp = temp.getNext();
        }
        return result;
    }
}
