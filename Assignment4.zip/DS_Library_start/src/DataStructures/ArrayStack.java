
package DataStructures;

import ADTs.StackADT;
import Exceptions.EmptyCollectionException;
import java.util.Arrays;
/**
 *
 * @author ITCS 2214
 */
public class ArrayStack<T> implements StackADT<T> {
    
    T stack[];
    int top;
    final static int DEFAULT_CAPACITY = 10;
    
    public ArrayStack(){
        stack = (T [])(new Object[DEFAULT_CAPACITY]);
        top = 0;
    }
    
    public ArrayStack(int capacity){
        //TODO
    }
    
@Override
    public void push(T element) {
        //TODO
        stack[top] = element;
        top++;
        
        //
        

    }

    @Override
    public T pop() throws EmptyCollectionException {
        //TODO
        //retrieve elt in the index top -1 and save it to a variable temp
         T temp = stack[top -1];
         //decraease top by 1
         top--;
         //assign null to the top of the stack
         stack[top] = null;
         //return temp
         return null;

    }

    @Override
    public T peek() throws EmptyCollectionException {
        //TODO
        return stack[top];

    }

    @Override
    public boolean isEmpty() {
        return false;
        //TODO
    }

    @Override
    public int size() {
        return 0;
       //TODO
    }
    
    private void expandCapacity() { 
        this.stack = Arrays.copyOf(this.stack, this.stack.length * 2); 
    }



    public static void main(String argv[]){
        StackADT<String> cities = new ArrayStack<String>();
        try{
            cities.push("Tokyo");
            cities.push("Atlanta");
            cities.pop();
            cities.pop();
            cities.push("Miami");
            cities.pop();
            cities.push("Charlotte");
            					System.out.println("Charlotte".equalsIgnoreCase(cities.peek()));
            System.out.println(1 == cities.size());
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

}
