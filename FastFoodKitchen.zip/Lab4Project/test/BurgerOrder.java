/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author National Pawn
 */
class BurgerOrder {

    BurgerOrder(int i, int i0, int i1, int i2, boolean b, int nextOrderNum) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    BurgerOrder(int ham, int cheese, int veggie, int soda, boolean TOGO) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
