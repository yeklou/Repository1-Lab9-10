
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author National Pawn
 */
public class FastFoodKitchen {
    private ArrayList <BurgerOrder> orderList = new ArrayList();

    private static int nextOrderNum;

    /**
     * Get the value of nextOrderNum
     *
     * @return the value of nextOrderNum
     */
    public static int getNextOrderNum() {
        return nextOrderNum;
    }
    
    private static void incrementNextOrderNum(){
        nextOrderNum++;
    }

    public FastFoodKitchen() {
    orderList.add(new BurgerOrder(3, 5, 4, 10, false, getNextOrderNum()));
    getNextOrderNum();
    incrementNextOrderNum();
    
    }
    
    public int addOrder(int ham, int cheese, int veggie, int soda, 
            boolean TOGO){
     BurgerOrder order = new BurgerOrder(ham, cheese, veggie, soda, TOGO);
     orderList.add(order);
     getNextOrderNum();
     incrementNextOrderNum();
     return nextOrderNum;
     
    } 
    
    public boolean isOrderDone(int orderID){
     for( BurgerOrder order : orderList)
        if(nextOrderNum == orderID)
            return false;
        else
            return true;
        return false;
        

    }
    
    private void orderCallOut(BurgerOrder order){
    // for(BurgerOrder order: orderList)
      if(orderList.size() > 0)
          System.out.println(order);
    }
    
    private void completeSpecificOrder(int orderID){
    for(BurgerOrder order: orderList)
      if(order.equals(orderID))
       System.out.println("The order is done.");
       orderCallOut(orderList.get(orderID));
       orderList.remove(orderID);
    }
    
    private void completeNextOrder(){
     System.out.println(orderList.get(0)+ "is done");
     orderCallOut(orderList.get(0));
     orderList.remove(orderList.get(0));
     
    }
    
    public int getNumOrdersPending(){
    return orderList.size();
   }
    
    public void simulateKitchenActivity(){
    // See if there is anything to do
    if(orderList.size() == 0)
        return;
    //simulate how orders are complited, usually
    // first-in, first-out, but not always 
    int num = (int)(Math.random()*100);
    if(num< 90){
    // 90% chance the kitchen completes the order that is at 
    //the front of the queue
    completeNextOrder();
    } else {
    //complete some random order
    int size = orderList.size();
    int id = (int)(Math.random()*size);
    completeSpecificOrder(id);
     }
    } 

    @Override
    public String toString() {
        return "FastFoodKitchen{" + "orderList=" + orderList + '}';
    }
    
    public boolean cancelOrder(int orderID){
      for(BurgerOrder order : orderList)
          if(order.equals(orderID))
          {
              orderList.remove(orderList.get(orderID));
              return true;
          }
          else
             return false;
        return false;
             
                  
     }


    }
   
