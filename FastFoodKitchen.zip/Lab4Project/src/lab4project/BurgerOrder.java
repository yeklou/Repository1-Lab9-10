/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4project;

/**
 *
 * @author National Pawn
 */
public class BurgerOrder {
 
    private int numHamburgers = 0;
    
    private int numCheeseburgers = 0;
    
    private int numVeggieburgers = 0;
    
    private int numSodas = 0;
    
    private boolean orderTogo = false;
    
    private int orderNum = 1;

    public BurgerOrder(int Hamburgers, int Cheeseburgers, 
                     int Veggieburgers, int Sodas, boolean takeout, int num) {
        numHamburgers = Hamburgers;
        numCheeseburgers = Cheeseburgers;
        numVeggieburgers = Veggieburgers;
        numSodas = Sodas;
        orderTogo = takeout;
        orderNum = num;
    }
    

    /**
     * Get the value of orderNum
     *
     * @return the value of orderNum
     */
    public int getOrderNum() {
        return orderNum;
    }

    /**
     * Set the value of orderNum
     *
     * @param orderNum new value of orderNum
     */
    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }


    /**
     * Get the value of orderTogo
     *
     * @return the value of orderTogo
     */
    public boolean isOrderTogo() {
        return orderTogo;
    }

    /**
     * Set the value of orderTogo
     *
     * @param orderTogo new value of orderTogo
     */
    public void setOrderTogo(boolean orderTogo) {
        this.orderTogo = orderTogo;
    }


    /**
     * Get the value of numSodas
     *
     * @return the value of numSodas
     */
    public int getNumSodas() {
        return numSodas;
    }

    /**
     * Set the value of numSodas
     *
     * @param numSodas new value of numSodas
     */
    public void setNumSodas(int numSodas) {
       if(numSodas < 0)
           System.out.println("Error!");
        this.numSodas = numSodas;
    }


    /**
     * Get the value of numVeggieburgers
     *
     * @return the value of numVeggieburgers
     */
    public int getNumVeggieburgers() {
        return numVeggieburgers;
    }

    /**
     * Set the value of numVeggieburgers
     *
     * @param numVeggieburgers new value of numVeggieburgers
     */
    public void setNumVeggieburgers(int numVeggieburgers) {
         if(numVeggieburgers < 0)
           System.out.println("Error!");
        this.numVeggieburgers = numVeggieburgers;
    }


    /**
     * Get the value of numCheeseburgers
     *
     * @return the value of numCheeseburgers
     */
    public int getNumCheeseburgers() {
        return numCheeseburgers;
    }

    /**
     * Set the value of numCheeseburgers
     *
     * @param numCheeseburgers new value of numCheeseburgers
     */
    public void setNumCheeseburgers(int numCheeseburgers) {
         if(numCheeseburgers < 0)
           System.out.println("Error!");
            this.numCheeseburgers = numCheeseburgers;
    }


    /**
     * Get the value of numHamburgers
     *
     * @return the value of numHamburgers
     */
    public int getNumHamburgers() {
        return numHamburgers;
    }

    /**
     * Set the value of numHamburgers
     *
     * @param numHamburgers new value of numHamburgers
     */
    public void setNumHamburgers(int numHamburgers) {
       if(numHamburgers < 0)
           System.out.println("Error!");
        this.numHamburgers = numHamburgers;
    }

    @Override
    public String toString() {
        return "BurgerOrder{" + "numHamburgers=" + numHamburgers + ", numCheeseburgers=" + numCheeseburgers + ", numVeggieburgers=" + numVeggieburgers + ", numSodas=" + numSodas + ", orderTogo=" + orderTogo + ", orderNum=" + orderNum + '}';
    }
    
   
}
