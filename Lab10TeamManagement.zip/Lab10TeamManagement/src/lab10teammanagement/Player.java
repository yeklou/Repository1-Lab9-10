package lab10teammanagement;


import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author National Pawn
 */
public class Player implements Comparable <Player>{
    //Fields
    String name;
    int age;
    int jerseyNumber;
    Position position;
   
    
    public Player(String name, int age, int jerseyNumber, Position position){
        this.name = name;
        this.age =age;
        this.jerseyNumber = jerseyNumber;
        this.position = position;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getJerseyNumber() {
        return jerseyNumber;
    }

    public void setJerseyNumber(int jerseyNumber) {
        this.jerseyNumber = jerseyNumber;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    

    
    @Override
    public String toString(){
    return name + " " + age + " "+ jerseyNumber + " "+ position;
    }

    /**
     *
     * @param other
     * @return
     
     */
    
    @Override
    public int compareTo(Player other){
        int comp = 0;
        while(this.position.equals(other.position)){ 
           if(this.jerseyNumber == other.jerseyNumber){
              comp = 0;
           }
        else
            comp = -1;
        }
        return comp;
    }
    
  
    
}
