package lab10teammanagement;


import lab10teammanagement.Position;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author National Pawn
 */
public class Start {
    public static void main(String []args){
Player p1 = new Player("Miles Bridges", 21, 0, Position.FORWARD);
Player p2 = new 
Player("Nicholas Batum", 24, 5, Position.FORWARD);
Player p3 = new Player("Malik Monk", 21, 1, Position.GUARD);
Team team = new Team("Hornets", "Charlotte");
team.addPlayer(p3);
team.addPlayer(p1);
team.addPlayer(p2);
System.out.println(team);
System.out.println("Sorting the players\n");
team.sortPlayers();
System.out.println
(team);
    }
    //public static Team loadTeamFromFile(String fileName)
    
}
